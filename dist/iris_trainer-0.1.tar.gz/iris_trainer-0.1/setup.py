from setuptools import find_packages, setup

setup(
    name="iris_trainer",
    version="0.1",
    packages=find_packages(),
    include_package_data=True,
    description="Iris model training application.",
)
